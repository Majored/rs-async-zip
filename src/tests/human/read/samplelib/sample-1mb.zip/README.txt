Sample 1MB ZIP archive from samplelib.com
Contents are random binary payloads sized to land near 1MB.
