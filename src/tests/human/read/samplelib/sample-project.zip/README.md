# Sample Project

A demonstration project layout used as a sample download.

## Installation

```
pip install -r requirements.txt
```

## Usage

```
python src/main.py
```

## License

MIT — see LICENSE file.
